<?php

/* index.html.twig */
class __TwigTemplate_67d14450a1a949a4836ee91b3c754b9bec43da1df3917b4c25c903ec027e20e6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "index.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6b7e3daa23cedd7a0461447a373afa965d82d867fd7a767feb8f8d7c409da60a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6b7e3daa23cedd7a0461447a373afa965d82d867fd7a767feb8f8d7c409da60a->enter($__internal_6b7e3daa23cedd7a0461447a373afa965d82d867fd7a767feb8f8d7c409da60a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "index.html.twig"));

        $__internal_75ae83fe079c3f01e4d890c002226d57202d4621a7784bc584c37c0e18a8e93b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_75ae83fe079c3f01e4d890c002226d57202d4621a7784bc584c37c0e18a8e93b->enter($__internal_75ae83fe079c3f01e4d890c002226d57202d4621a7784bc584c37c0e18a8e93b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6b7e3daa23cedd7a0461447a373afa965d82d867fd7a767feb8f8d7c409da60a->leave($__internal_6b7e3daa23cedd7a0461447a373afa965d82d867fd7a767feb8f8d7c409da60a_prof);

        
        $__internal_75ae83fe079c3f01e4d890c002226d57202d4621a7784bc584c37c0e18a8e93b->leave($__internal_75ae83fe079c3f01e4d890c002226d57202d4621a7784bc584c37c0e18a8e93b_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_a4144193b3573821735431ce46f6aea7e71e12d567877f5cbc16ec609efbbffa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a4144193b3573821735431ce46f6aea7e71e12d567877f5cbc16ec609efbbffa->enter($__internal_a4144193b3573821735431ce46f6aea7e71e12d567877f5cbc16ec609efbbffa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_27d55660f4da663000402794b5aeec86eb96f86c6fc699fa57752507afa52131 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_27d55660f4da663000402794b5aeec86eb96f86c6fc699fa57752507afa52131->enter($__internal_27d55660f4da663000402794b5aeec86eb96f86c6fc699fa57752507afa52131_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo " <div class=\"row\">
        <div class=\"col-md-7\">
            <ul>
                ";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) ? $context["categories"] : $this->getContext($context, "categories")));
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 8
            echo "                    <h3><a href=\"./category/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "title", array()), "html", null, true);
            echo "</a></h3>
                    ";
            // line 9
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["category"], "lastnews", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["lastnews"]) {
                // line 10
                echo "                        <p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"./news/";
                echo twig_escape_filter($this->env, $this->getAttribute($context["lastnews"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["lastnews"], "title", array()), "html", null, true);
                echo "</a></p>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['lastnews'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 12
            echo "                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 13
        echo "            </ul>
        </div>
    </div>
";
        
        $__internal_27d55660f4da663000402794b5aeec86eb96f86c6fc699fa57752507afa52131->leave($__internal_27d55660f4da663000402794b5aeec86eb96f86c6fc699fa57752507afa52131_prof);

        
        $__internal_a4144193b3573821735431ce46f6aea7e71e12d567877f5cbc16ec609efbbffa->leave($__internal_a4144193b3573821735431ce46f6aea7e71e12d567877f5cbc16ec609efbbffa_prof);

    }

    public function getTemplateName()
    {
        return "index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  86 => 13,  80 => 12,  69 => 10,  65 => 9,  58 => 8,  54 => 7,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layout.html.twig\" %}

{% block content %}
 <div class=\"row\">
        <div class=\"col-md-7\">
            <ul>
                {% for category in categories %}
                    <h3><a href=\"./category/{{ category.id }}\">{{ category.title }}</a></h3>
                    {% for  lastnews in category.lastnews %}
                        <p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"./news/{{ lastnews.id }}\">{{ lastnews.title }}</a></p>
                    {% endfor %}
                {% endfor %}
            </ul>
        </div>
    </div>
{% endblock %}
", "index.html.twig", "D:\\xammp\\htdocs\\site\\templates\\index.html.twig");
    }
}
