<?php

/* news.html.twig */
class __TwigTemplate_0fdde1065937dc5005f9c5ceea1c46ded510774b9479e75c508e9ab49f49f808 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "news.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8864a875613923be6999469e9dbcac10c71cb41f9379bbb8222f8fd8c05046e4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8864a875613923be6999469e9dbcac10c71cb41f9379bbb8222f8fd8c05046e4->enter($__internal_8864a875613923be6999469e9dbcac10c71cb41f9379bbb8222f8fd8c05046e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "news.html.twig"));

        $__internal_3f4465aba210401c6815ba2c65ea4b263bed9c1aeeb9e1a412b7097d4af77b3f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3f4465aba210401c6815ba2c65ea4b263bed9c1aeeb9e1a412b7097d4af77b3f->enter($__internal_3f4465aba210401c6815ba2c65ea4b263bed9c1aeeb9e1a412b7097d4af77b3f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "news.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8864a875613923be6999469e9dbcac10c71cb41f9379bbb8222f8fd8c05046e4->leave($__internal_8864a875613923be6999469e9dbcac10c71cb41f9379bbb8222f8fd8c05046e4_prof);

        
        $__internal_3f4465aba210401c6815ba2c65ea4b263bed9c1aeeb9e1a412b7097d4af77b3f->leave($__internal_3f4465aba210401c6815ba2c65ea4b263bed9c1aeeb9e1a412b7097d4af77b3f_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_398d2f93cf2f57921088ed20cf3d457a009257dd8168b1c9c01e7e0f0c55a4de = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_398d2f93cf2f57921088ed20cf3d457a009257dd8168b1c9c01e7e0f0c55a4de->enter($__internal_398d2f93cf2f57921088ed20cf3d457a009257dd8168b1c9c01e7e0f0c55a4de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_bdb6ac06877cf61ac884037927df900ea33d6034bb45adfabef6f3bb95986442 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bdb6ac06877cf61ac884037927df900ea33d6034bb45adfabef6f3bb95986442->enter($__internal_bdb6ac06877cf61ac884037927df900ea33d6034bb45adfabef6f3bb95986442_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h1>";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["news"]) ? $context["news"] : $this->getContext($context, "news")), "title", array()), "html", null, true);
        echo "</h1>
    <br>
    ";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["news"]) ? $context["news"] : $this->getContext($context, "news")), "content", array()), "html", null, true);
        echo "
";
        
        $__internal_bdb6ac06877cf61ac884037927df900ea33d6034bb45adfabef6f3bb95986442->leave($__internal_bdb6ac06877cf61ac884037927df900ea33d6034bb45adfabef6f3bb95986442_prof);

        
        $__internal_398d2f93cf2f57921088ed20cf3d457a009257dd8168b1c9c01e7e0f0c55a4de->leave($__internal_398d2f93cf2f57921088ed20cf3d457a009257dd8168b1c9c01e7e0f0c55a4de_prof);

    }

    public function getTemplateName()
    {
        return "news.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  55 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layout.html.twig\" %}

{% block content %}
    <h1>{{ news.title }}</h1>
    <br>
    {{ news.content }}
{% endblock %}", "news.html.twig", "D:\\xammp\\htdocs\\site\\templates\\news.html.twig");
    }
}
