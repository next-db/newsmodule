<?php

/* layout.html.twig */
class __TwigTemplate_65329ae4f9ff17d1eed745fea27562abb3b774e2c5fb121056033192ed952da9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_685427a57349f5bdf064471942682829193a7e37981a046be702896917a4ae69 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_685427a57349f5bdf064471942682829193a7e37981a046be702896917a4ae69->enter($__internal_685427a57349f5bdf064471942682829193a7e37981a046be702896917a4ae69_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        $__internal_d339a19388b5e61f1af74f70c6b499a9c8a1572f5b7c683fe7f7b868ef291244 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d339a19388b5e61f1af74f70c6b499a9c8a1572f5b7c683fe7f7b868ef291244->enter($__internal_d339a19388b5e61f1af74f70c6b499a9c8a1572f5b7c683fe7f7b868ef291244_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>

        <meta charset=\"utf-8\">
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
        <meta name=\"description\" content=\"\">
        <meta name=\"author\" content=\"\">

        <title>1 Col Portfolio - Start Bootstrap Template</title>

        <!-- Bootstrap Core CSS -->
        <link href=\"css/bootstrap.min.css\" rel=\"stylesheet\">

        <!-- Custom CSS -->
        <link href=\"css/1-col-portfolio.css\" rel=\"stylesheet\">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src=\"https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js\"></script>
        <script src=\"https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js\"></script>
        <![endif]-->

        <title>";
        // line 26
        $this->displayBlock('title', $context, $blocks);
        echo " - My Silex Application</title>

        <link href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/main.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" />

        <script type=\"text/javascript\">
            var _gaq = _gaq || [];
            _gaq.push(['_setAccount', 'UA-XXXXXXXX-X']);
            _gaq.push(['_trackPageview']);

            (function() {
                var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
                ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
                var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
            })();
        </script>
    </head>
    <body>
    <!--nav class=\"navbar navbar-inverse navbar-fixed-top\" role=\"navigation\">
        <div class=\"container\">
            <!-- Brand and toggle get grouped for better mobile display -->
            <!--div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\">
                    <span class=\"sr-only\">Toggle navigation</span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                </button>
                <a class=\"navbar-brand\" href=\"#\">Start Bootstrap</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <!--div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
                <ul class=\"nav navbar-nav\">
                    <li>
                        <a href=\"#\">About</a>
                    </li>
                    <li>
                        <a href=\"#\">Services</a>
                    </li>
                    <li>
                        <a href=\"#\">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse >
        </div>
        <!-- /.container >
    </nav-->

    <!-- Page Content -->
    <div class=\"container\">
        ";
        // line 76
        $this->displayBlock('content', $context, $blocks);
        // line 77
        echo "
    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src=\"js/jquery.js\"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src=\"js/bootstrap.min.js\"></script>
    </body>
</html>
";
        
        $__internal_685427a57349f5bdf064471942682829193a7e37981a046be702896917a4ae69->leave($__internal_685427a57349f5bdf064471942682829193a7e37981a046be702896917a4ae69_prof);

        
        $__internal_d339a19388b5e61f1af74f70c6b499a9c8a1572f5b7c683fe7f7b868ef291244->leave($__internal_d339a19388b5e61f1af74f70c6b499a9c8a1572f5b7c683fe7f7b868ef291244_prof);

    }

    // line 26
    public function block_title($context, array $blocks = array())
    {
        $__internal_0597bbd26e0acb36f18063c7988bdfdfde38147c98b15a16751501db920e7cf4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0597bbd26e0acb36f18063c7988bdfdfde38147c98b15a16751501db920e7cf4->enter($__internal_0597bbd26e0acb36f18063c7988bdfdfde38147c98b15a16751501db920e7cf4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_727e7c4654e7429fd5fc412d5600e62c5b487b9a206d2ee44d70e341d453565e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_727e7c4654e7429fd5fc412d5600e62c5b487b9a206d2ee44d70e341d453565e->enter($__internal_727e7c4654e7429fd5fc412d5600e62c5b487b9a206d2ee44d70e341d453565e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "";
        
        $__internal_727e7c4654e7429fd5fc412d5600e62c5b487b9a206d2ee44d70e341d453565e->leave($__internal_727e7c4654e7429fd5fc412d5600e62c5b487b9a206d2ee44d70e341d453565e_prof);

        
        $__internal_0597bbd26e0acb36f18063c7988bdfdfde38147c98b15a16751501db920e7cf4->leave($__internal_0597bbd26e0acb36f18063c7988bdfdfde38147c98b15a16751501db920e7cf4_prof);

    }

    // line 76
    public function block_content($context, array $blocks = array())
    {
        $__internal_0b44def4d5d8c1d773c793a7c450c7975aebb80059a71cd024ace8a9847cc747 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0b44def4d5d8c1d773c793a7c450c7975aebb80059a71cd024ace8a9847cc747->enter($__internal_0b44def4d5d8c1d773c793a7c450c7975aebb80059a71cd024ace8a9847cc747_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_3a14da5a1ba7aa408e26101789045e5c3dee08558aece53111145460a8c3c7b8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3a14da5a1ba7aa408e26101789045e5c3dee08558aece53111145460a8c3c7b8->enter($__internal_3a14da5a1ba7aa408e26101789045e5c3dee08558aece53111145460a8c3c7b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_3a14da5a1ba7aa408e26101789045e5c3dee08558aece53111145460a8c3c7b8->leave($__internal_3a14da5a1ba7aa408e26101789045e5c3dee08558aece53111145460a8c3c7b8_prof);

        
        $__internal_0b44def4d5d8c1d773c793a7c450c7975aebb80059a71cd024ace8a9847cc747->leave($__internal_0b44def4d5d8c1d773c793a7c450c7975aebb80059a71cd024ace8a9847cc747_prof);

    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  151 => 76,  133 => 26,  112 => 77,  110 => 76,  59 => 28,  54 => 26,  27 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>

        <meta charset=\"utf-8\">
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
        <meta name=\"description\" content=\"\">
        <meta name=\"author\" content=\"\">

        <title>1 Col Portfolio - Start Bootstrap Template</title>

        <!-- Bootstrap Core CSS -->
        <link href=\"css/bootstrap.min.css\" rel=\"stylesheet\">

        <!-- Custom CSS -->
        <link href=\"css/1-col-portfolio.css\" rel=\"stylesheet\">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src=\"https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js\"></script>
        <script src=\"https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js\"></script>
        <![endif]-->

        <title>{% block title '' %} - My Silex Application</title>

        <link href=\"{{ asset('css/main.css') }}\" rel=\"stylesheet\" type=\"text/css\" />

        <script type=\"text/javascript\">
            var _gaq = _gaq || [];
            _gaq.push(['_setAccount', 'UA-XXXXXXXX-X']);
            _gaq.push(['_trackPageview']);

            (function() {
                var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
                ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
                var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
            })();
        </script>
    </head>
    <body>
    <!--nav class=\"navbar navbar-inverse navbar-fixed-top\" role=\"navigation\">
        <div class=\"container\">
            <!-- Brand and toggle get grouped for better mobile display -->
            <!--div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\">
                    <span class=\"sr-only\">Toggle navigation</span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                </button>
                <a class=\"navbar-brand\" href=\"#\">Start Bootstrap</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <!--div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
                <ul class=\"nav navbar-nav\">
                    <li>
                        <a href=\"#\">About</a>
                    </li>
                    <li>
                        <a href=\"#\">Services</a>
                    </li>
                    <li>
                        <a href=\"#\">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse >
        </div>
        <!-- /.container >
    </nav-->

    <!-- Page Content -->
    <div class=\"container\">
        {% block content %}{% endblock %}

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src=\"js/jquery.js\"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src=\"js/bootstrap.min.js\"></script>
    </body>
</html>
", "layout.html.twig", "D:\\xammp\\htdocs\\site\\templates\\layout.html.twig");
    }
}
