<?php

/* category.html.twig */
class __TwigTemplate_412a63047938d7ba243db3bf9d987d2025c8ce6137f9b82cc1598e08bf8ae73d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "category.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7dc39d96f6325bb2c465b8d318e85c74e542b13d07a0e79c5e061522ff621e21 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7dc39d96f6325bb2c465b8d318e85c74e542b13d07a0e79c5e061522ff621e21->enter($__internal_7dc39d96f6325bb2c465b8d318e85c74e542b13d07a0e79c5e061522ff621e21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category.html.twig"));

        $__internal_5b057e8481ce0c89345c3a6db31364b7a0625b98365b35da4de9427aaca9ef34 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5b057e8481ce0c89345c3a6db31364b7a0625b98365b35da4de9427aaca9ef34->enter($__internal_5b057e8481ce0c89345c3a6db31364b7a0625b98365b35da4de9427aaca9ef34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7dc39d96f6325bb2c465b8d318e85c74e542b13d07a0e79c5e061522ff621e21->leave($__internal_7dc39d96f6325bb2c465b8d318e85c74e542b13d07a0e79c5e061522ff621e21_prof);

        
        $__internal_5b057e8481ce0c89345c3a6db31364b7a0625b98365b35da4de9427aaca9ef34->leave($__internal_5b057e8481ce0c89345c3a6db31364b7a0625b98365b35da4de9427aaca9ef34_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_ec888d85ffbe82b0f95ed3561c080d912d185a268ec137b9df9197da3edbf95e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ec888d85ffbe82b0f95ed3561c080d912d185a268ec137b9df9197da3edbf95e->enter($__internal_ec888d85ffbe82b0f95ed3561c080d912d185a268ec137b9df9197da3edbf95e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_4cf2b238e5b08f30e970d72b790be26b7c12ecac68a65fe136c59c9d1f05683c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4cf2b238e5b08f30e970d72b790be26b7c12ecac68a65fe136c59c9d1f05683c->enter($__internal_4cf2b238e5b08f30e970d72b790be26b7c12ecac68a65fe136c59c9d1f05683c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <div class=\"row\">
        <div class=\"col-md-7\">
            <h3>";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["categorytitle"]) ? $context["categorytitle"] : $this->getContext($context, "categorytitle")), "title", array()), "html", null, true);
        echo "</h3>
            ";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categorynews"]) ? $context["categorynews"] : $this->getContext($context, "categorynews")));
        foreach ($context['_seq'] as $context["_key"] => $context["categorynewses"]) {
            // line 8
            echo "                <p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"../news/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["categorynewses"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["categorynewses"], "title", array()), "html", null, true);
            echo "</a></p>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['categorynewses'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 10
        echo "        </div>
    </div>
";
        
        $__internal_4cf2b238e5b08f30e970d72b790be26b7c12ecac68a65fe136c59c9d1f05683c->leave($__internal_4cf2b238e5b08f30e970d72b790be26b7c12ecac68a65fe136c59c9d1f05683c_prof);

        
        $__internal_ec888d85ffbe82b0f95ed3561c080d912d185a268ec137b9df9197da3edbf95e->leave($__internal_ec888d85ffbe82b0f95ed3561c080d912d185a268ec137b9df9197da3edbf95e_prof);

    }

    public function getTemplateName()
    {
        return "category.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 10,  61 => 8,  57 => 7,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layout.html.twig\" %}

{% block content %}
    <div class=\"row\">
        <div class=\"col-md-7\">
            <h3>{{ categorytitle.title }}</h3>
            {% for categorynewses in categorynews %}
                <p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"../news/{{ categorynewses.id }}\">{{ categorynewses.title }}</a></p>
            {% endfor %}
        </div>
    </div>
{% endblock %}", "category.html.twig", "D:\\xammp\\htdocs\\site\\templates\\category.html.twig");
    }
}
