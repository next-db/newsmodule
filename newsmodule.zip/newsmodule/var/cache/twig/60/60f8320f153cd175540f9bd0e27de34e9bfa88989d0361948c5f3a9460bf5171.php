<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_f1567a737868d3e3b45d3d9e416741f20f4283f8c96c2db34321cf838812b6c9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b6b53bda7e2196b699d3b27d9d8590e3bc5a0d17a72618b896fb9783c9508c47 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b6b53bda7e2196b699d3b27d9d8590e3bc5a0d17a72618b896fb9783c9508c47->enter($__internal_b6b53bda7e2196b699d3b27d9d8590e3bc5a0d17a72618b896fb9783c9508c47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_f5bc5459ad52b22e56b1bd31a5a62f2b8eca7e8677640904427252d017a233a8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f5bc5459ad52b22e56b1bd31a5a62f2b8eca7e8677640904427252d017a233a8->enter($__internal_f5bc5459ad52b22e56b1bd31a5a62f2b8eca7e8677640904427252d017a233a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b6b53bda7e2196b699d3b27d9d8590e3bc5a0d17a72618b896fb9783c9508c47->leave($__internal_b6b53bda7e2196b699d3b27d9d8590e3bc5a0d17a72618b896fb9783c9508c47_prof);

        
        $__internal_f5bc5459ad52b22e56b1bd31a5a62f2b8eca7e8677640904427252d017a233a8->leave($__internal_f5bc5459ad52b22e56b1bd31a5a62f2b8eca7e8677640904427252d017a233a8_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_59f7128d0ea1c583dacb509e5067a2b4168ef6f34834e447d4ea33700b5e0da8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_59f7128d0ea1c583dacb509e5067a2b4168ef6f34834e447d4ea33700b5e0da8->enter($__internal_59f7128d0ea1c583dacb509e5067a2b4168ef6f34834e447d4ea33700b5e0da8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_7d878d49d93d99a962e57caaf1fdef2c9466e3f81374f651a417f4f2844484ab = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7d878d49d93d99a962e57caaf1fdef2c9466e3f81374f651a417f4f2844484ab->enter($__internal_7d878d49d93d99a962e57caaf1fdef2c9466e3f81374f651a417f4f2844484ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_7d878d49d93d99a962e57caaf1fdef2c9466e3f81374f651a417f4f2844484ab->leave($__internal_7d878d49d93d99a962e57caaf1fdef2c9466e3f81374f651a417f4f2844484ab_prof);

        
        $__internal_59f7128d0ea1c583dacb509e5067a2b4168ef6f34834e447d4ea33700b5e0da8->leave($__internal_59f7128d0ea1c583dacb509e5067a2b4168ef6f34834e447d4ea33700b5e0da8_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_ee5f15f99330b2126d3042f3a539cfb97a2e97e60a9147969670464273f5da14 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ee5f15f99330b2126d3042f3a539cfb97a2e97e60a9147969670464273f5da14->enter($__internal_ee5f15f99330b2126d3042f3a539cfb97a2e97e60a9147969670464273f5da14_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_caa7adfb07cc6aa687b34c795581e7ebba34e9aadd3b97590c24fc0f0ae758fe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_caa7adfb07cc6aa687b34c795581e7ebba34e9aadd3b97590c24fc0f0ae758fe->enter($__internal_caa7adfb07cc6aa687b34c795581e7ebba34e9aadd3b97590c24fc0f0ae758fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_caa7adfb07cc6aa687b34c795581e7ebba34e9aadd3b97590c24fc0f0ae758fe->leave($__internal_caa7adfb07cc6aa687b34c795581e7ebba34e9aadd3b97590c24fc0f0ae758fe_prof);

        
        $__internal_ee5f15f99330b2126d3042f3a539cfb97a2e97e60a9147969670464273f5da14->leave($__internal_ee5f15f99330b2126d3042f3a539cfb97a2e97e60a9147969670464273f5da14_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_8ea5b7f2f3296f0cc464448c3fda4efeee00791701e419ca974b1917cdcb9cf7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ea5b7f2f3296f0cc464448c3fda4efeee00791701e419ca974b1917cdcb9cf7->enter($__internal_8ea5b7f2f3296f0cc464448c3fda4efeee00791701e419ca974b1917cdcb9cf7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_821bf8af714fe364f44c262a9f1c7d7a325e378017e41bc1817db91eb996f093 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_821bf8af714fe364f44c262a9f1c7d7a325e378017e41bc1817db91eb996f093->enter($__internal_821bf8af714fe364f44c262a9f1c7d7a325e378017e41bc1817db91eb996f093_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_821bf8af714fe364f44c262a9f1c7d7a325e378017e41bc1817db91eb996f093->leave($__internal_821bf8af714fe364f44c262a9f1c7d7a325e378017e41bc1817db91eb996f093_prof);

        
        $__internal_8ea5b7f2f3296f0cc464448c3fda4efeee00791701e419ca974b1917cdcb9cf7->leave($__internal_8ea5b7f2f3296f0cc464448c3fda4efeee00791701e419ca974b1917cdcb9cf7_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "D:\\xammp\\htdocs\\site\\vendor\\symfony\\web-profiler-bundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
