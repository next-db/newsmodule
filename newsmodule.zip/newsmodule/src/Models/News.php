<?php


namespace Models;


class News
{
    public function getNewsById($id) {
        global $app;
        $db = $app['db'];
        $db->where ("id", $id);
        $news = $db->getOne ("site_news");
        return $news;
    }

    public function getLastNewsInCategory($id) {
        global $app;
        $db = $app['db'];
        $db->where ("category", $id);
        $allNews = $db->rawQuery ('SELECT * FROM site_news where category=? ORDER BY created DESC limit ? ', Array ($id, 5));
        return $allNews;
    }
    public function getLastNewsByCategories() {
        global $app;
        $db = $app['db'];
        $categories = $db->get('site_category');
        foreach ($categories as &$category) {
            $last_news_for_category = $db->rawQuery ('SELECT * from site_news where category=? order by created desc limit ? ', Array ($category['id'], 5));
            $category['lastnews'] = $last_news_for_category ;
        }
        return $categories;
    }
    public function getCategory($id){
        global $app;
        $db = $app['db'];
        $db ->where ('id',$id);
        $categoryTitle = $db -> getOne('site_category');
        return $categoryTitle;
    }
    /*public function getPage($id) {
        global $app;
        $db = $app['db'];
        $db -> where ("category", $id);
        $all = $db->rawQuery ('SELECT COUNT(id) FROM site_news WHERE category=?', Array ($id));
        $lim = 5;
        $prev = 5;
        $link = "http://site/category/" . $id . "/";
        $curr_link = 1;
        $first = $curr_link - $prev;
        if ($first < 1) $first = 1;
        $last = $curr_link + $prev;
        if ($last > ceil($all/$lim)) $last = ceil($all/$lim);

        // начало вывода нумерации
        // выводим первую страницу
        $y = 1;
        if ($first > 1) echo "<a href='{$link}?page={$y}'>1</a> ";
        // Если текущая страница далеко от 1-й (>10), то часть предыдущих страниц
        // скрываем троеточием
        // Если текущая страница имеет номер до 10, то выводим все номера
        // перед заданным диапазоном без скрытия
        $y = $first - 1;
        if ($first > 10) {
            echo "<a href='{$link}?page={$y}'>...</a> ";
        } else {
            for($i = 2;$i < $first;$i++){
                echo "<a href='{$link}?page={$i}'>$i</a> ";
            }
        }
        // отображаем заданный диапазон: текущая страница +-$prev
        for($i = $first;$i < $last + 1;$i++){
            // если выводится текущая страница, то ей назначается особый стиль css
            if($i == $curr_link) { ?>

                <span><?php echo $i; ?></span>
            <?php } else {
                $alink = "<a href='{$link}";
                if($i != 1) $alink .= "?page={$i}";
                $alink .= "'>$i</a> ";
                echo $alink;
            }
        }
        $y = $last + 1;
        // часть страниц скрываем троеточием
        if ($last < ceil($all / $lim) && ceil($all / $lim) - $last > 2) echo "<a href='{$link}?page={$y}'>...</a> ";
        // выводим последнюю страницу
        $e = ceil($all / $lim);
        if ($last < ceil($all / $lim)) echo "<a href='{$link}?page={$e}'>$e</a>";
    }*/
}