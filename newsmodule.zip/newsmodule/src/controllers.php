<?php

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Models\News;

//Request::setTrustedProxies(array('127.0.0.1'));

/*$app->get('/', function () use ($app) {
    $an = new News();
    $allNewsLast = $an -> getLastNews(5);
    return $app['twig']->render('index.html.twig', array('allNews' => $allNewsLast));
})
->bind('homepage')
;*/

$app->get('/', function () use ($app) {
    $an = new News();
    $allNewsLastCategory = $an -> getLastNewsByCategories();
    return $app['twig']->render('index.html.twig', array('categories' => $allNewsLastCategory));
})
    ->bind('homepage')
;


$app->get('/news/{id}', function ($id) use ($app) {
    $n = new News();
    $correntNews = $n -> getNewsById($id);
    return $app['twig']->render('news.html.twig', array('id' => $id,'news' => $correntNews));
})->bind('newspage');


$app->get('/category/{id}', function ($id) use ($app) {
    $cn =new News();
    $ct = new News();
    $p = new News();
    $categoryNews = $cn -> getLastNewsInCategory($id);
    $categoryTitle = $ct -> getCategory($id);
    //$pages = $p ->getPage($id);
    //echo '<pre>';var_dump($pages);exit;echo '</pre>';
    return $app['twig']->render('category.html.twig', array('category' => $id, 'categorynews' => $categoryNews, 'categorytitle' => $categoryTitle));
})->bind('categorypage');



$app->error(function (\Exception $e, Request $request, $code) use ($app) {
    if ($app['debug']) {
        return;
    }

    // 404.html, or 40x.html, or 4xx.html, or error.html
    $templates = array(
        'errors/'.$code.'.html.twig',
        'errors/'.substr($code, 0, 2).'x.html.twig',
        'errors/'.substr($code, 0, 1).'xx.html.twig',
        'errors/default.html.twig',
    );

    return new Response($app['twig']->resolveTemplate($templates)->render(array('code' => $code)), $code);
});
